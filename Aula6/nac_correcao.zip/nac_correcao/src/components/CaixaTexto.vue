<template>
  <div>
    {{rotulo}}
    <input ref="cx" type="text" v-model="dados" v-on:keyup="enter" v-on:change="altera" />
  </div>
</template>

<script>
export default {
  name: "CaixaTexto",
  props: ["rotulo"],
  data(){
    return {
      dados: "",
    }
  },
  methods:{
    altera(){
      this.$emit("alterou", this.dados);
    },
    limpa(){
      this.dados = "";
    },
    enter(evento){
      if(evento.key=='Enter'){
        this.$emit("enter");
      }
    },
    focaCursor(){
      this.$refs.cx.focus();
    }
  }
}
</script>

<style>

</style>

