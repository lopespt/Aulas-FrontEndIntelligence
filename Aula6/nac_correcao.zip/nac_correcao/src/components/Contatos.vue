<template>
  <div>
    <h2>{{rotulo}}</h2>
    <div>
      <div :key="idx" class="lista" v-for="(item, idx) in lista">
        <div>Nome: {{item.nome}} </div>
        <div>Telefone: {{item.telefone}}</div>
        <Botao rotulo="excluir" v-on:clicou="emiteDeletar(idx)"/>
      </div>
    </div>
  </div>
</template>

<script>
import Botao from './Botao.vue';
export default {
  name: "Contatos",
  props: ["rotulo", "lista"],
  components:{
    Botao
  },
  methods:{
    altera(){
      this.$emit("alterou", this.dados);
    },
    emiteDeletar(idx){
      this.$emit("deleta", idx);
    }
  }
}
</script>

<style>
.lista div{
  text-align: left;
  width: 30%;
  display: inline-block;
}
</style>

