<template>
  <div>
    <CaixaTexto ref="cx1" rotulo="Nome:" v-on:alterou="atualizaNome" v-on:enter="focaTel"/>
    <CaixaTexto ref="cx2" rotulo="Telefone:" v-on:alterou="atualizaTelefone" v-on:enter="adicionar"/>
    <Botao rotulo="Adicionar" v-on:clicou="adicionar"/>
    <Contatos rotulo="Lista de Contatos" :lista="agenda" v-on:deleta="deletar" />
  </div>
</template>

<script>
import CaixaTexto from './CaixaTexto.vue';
import Botao from './Botao.vue';
import Contatos from './Contatos.vue';
export default {
  name: 'Agenda',
  components: {
    CaixaTexto,
    Botao,
    Contatos
  },
  props: {
    msg: String
  },
  data(){
    return {
      nome: "",
      telefone: "",
      agenda: []
    }
  },
  methods:{
    atualizaNome(texto){
      this.nome = texto;
    },
    atualizaTelefone(texto){
      this.telefone = texto;
    },
    focaTel(){
      this.$refs.cx2.focaCursor();
    },
    adicionar(){
      var novaPessoa = {nome: this.nome, telefone: this.telefone};
      this.agenda.push(novaPessoa);
      this.$refs.cx1.limpa();
      this.$refs.cx2.limpa();
      this.$refs.cx1.focaCursor();
    },
    deletar(idx){
      this.agenda.splice(idx,1);
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
</style>
