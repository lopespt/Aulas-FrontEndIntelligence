<template>
  <div>
    <input type="button" v-on:click="lancaEvento" :value="rotulo" />
  </div>
</template>

<script>
export default {
  name: "Botao",
  props: ["rotulo"],
  methods:{
    lancaEvento(){
      this.$emit("clicou");
    }
  }
}
</script>

<style scoped>
div, input{
  display: inline-block;
}
</style>

