import Vue from "vue/dist/vue.esm"
import App from "./app.vue"

let app = new Vue({
    el: "#app",
    components: {
        App
    },
    template: "<App></App>"
});


