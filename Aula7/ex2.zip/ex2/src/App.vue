<template>
  <div id="app">
    <Entrada v-on:pressionouEnter="adicionar" ref="entrada"/>
    <Botao texto="Adicionar" v-on:clicou="adicionar" />
    <Botao texto="Resetar" v-on:clicou="limpa" />
    <ul>
        <li :key="indice" v-for="(item, indice) in items">
            {{item}}
        </li>
    </ul>
    </div>
</template>


<script>
import Entrada from './components/Entrada.vue'
import Botao from './components/Botao.vue'

export default {
  name: 'app',
  data(){
    return{
      items: []
    }
  },
  methods:{
    limpa(){
        this.items = [];
        this.$refs.entrada.limpa();
    },
    adicionar(){
        this.items.push(this.$refs.entrada.texto);
        this.$refs.entrada.limpa();
    }
    
  },
  components: {
    Entrada,
    Botao
  }
}
</script>

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
