<template>
  <div>
     <input type="text"  v-on:keyup="digitou" v-model="texto">
  </div>
</template>

<script>
export default {
  name: 'Entrada',
  data(){
    return {
        texto: ""
    }
  },
  methods:{
    digitou(evento){
        if(evento.key=="Enter")
          this.$emit("pressionouEnter", this.texto);
        else
          this.$emit("entrouDados", this.texto);
    },
    limpa(){
      this.texto = ""
    }
  }
}
</script>
