<template>
  <div>
     <input type="button" v-on:click="clicou" :value="texto" />
  </div>
</template>

<script>
export default {
  name: 'Botao',
  props: {
    texto: String
  },
  methods:{
    clicou(){
      this.$emit("clicou");
    }
  }
}
</script>
