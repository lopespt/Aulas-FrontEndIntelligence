<template>
  <div id="app">
    <Entrada v-on:entrouDados="atualiza" v-on:pressionouEnter="checar" ref="entrada"/>
    <Botao texto="Checar" v-on:clicou="checar" />
    <Botao texto="Resetar" />
    <div v-if="adivinhado != null">
      <div v-if="adivinhado < sorteado">
        É maior
      </div>
      <div v-else-if="adivinhado > sorteado">
        É menor
      </div>
      <div v-else-if="adivinhado == sorteado">
        Acertou!!
      </div>
    </div>
  </div>
</template>


<script>
import Entrada from './components/Entrada.vue'
import Botao from './components/Botao.vue'

export default {
  name: 'app',
  data(){
    return{
      sorteado: parseInt(Math.random() * 100),
      adivinhado: null,
      texto: ""
    }
  },
  methods:{
    atualiza(txt){
      this.texto = txt;
      //this.$refs.entrada.limpa();
    },
    checar(){
      
        this.adivinhado = parseInt(this.texto);
    }
    
  },
  components: {
    Entrada,
    Botao
  }
}
</script>

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
